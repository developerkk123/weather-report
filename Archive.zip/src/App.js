import './App.css';
import HomePage from './view/HomePage/HomePage';
import Weather from './view/HomePage/Weather/Weather';

function App() {
  return (
    <div className="App">
       <Weather />
    </div>
  );
}

export default App;
